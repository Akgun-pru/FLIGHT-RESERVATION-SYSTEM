﻿namespace FlightReservationSystem
{
    partial class DestinationCreate
    {
                                private System.ComponentModel.IContainer components = null;

                                        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

                                        private void InitializeComponent()
        {
            this.cbDeparture = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tbDestinationName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnCreate = new System.Windows.Forms.Button();
            this.cbArrival = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.tbCost = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
                                                this.cbDeparture.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbDeparture.FormattingEnabled = true;
            this.cbDeparture.Location = new System.Drawing.Point(15, 102);
            this.cbDeparture.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbDeparture.Name = "cbDeparture";
            this.cbDeparture.Size = new System.Drawing.Size(163, 24);
            this.cbDeparture.TabIndex = 1;
                                                this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(110, 16);
            this.label1.TabIndex = 4;
            this.label1.Text = "Departure City:";
                                                this.tbDestinationName.Location = new System.Drawing.Point(15, 41);
            this.tbDestinationName.Name = "tbDestinationName";
            this.tbDestinationName.Size = new System.Drawing.Size(182, 22);
            this.tbDestinationName.TabIndex = 0;
                                                this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(134, 16);
            this.label2.TabIndex = 4;
            this.label2.Text = "Destination Name:";
                                                this.btnCreate.Location = new System.Drawing.Point(15, 136);
            this.btnCreate.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnCreate.Name = "btnCreate";
            this.btnCreate.Size = new System.Drawing.Size(361, 32);
            this.btnCreate.TabIndex = 1;
            this.btnCreate.Text = "Create Destination";
            this.btnCreate.UseVisualStyleBackColor = true;
            this.btnCreate.Click += new System.EventHandler(this.btnCreate_Click);
                                                this.cbArrival.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbArrival.FormattingEnabled = true;
            this.cbArrival.Location = new System.Drawing.Point(204, 102);
            this.cbArrival.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.cbArrival.Name = "cbArrival";
            this.cbArrival.Size = new System.Drawing.Size(172, 24);
            this.cbArrival.TabIndex = 1;
                                                this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(201, 80);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(86, 16);
            this.label3.TabIndex = 4;
            this.label3.Text = "Arrival City:";
                                                this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(201, 20);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(89, 16);
            this.label4.TabIndex = 4;
            this.label4.Text = "Ticket Cost:";
                                                this.tbCost.Location = new System.Drawing.Point(204, 41);
            this.tbCost.Name = "tbCost";
            this.tbCost.Size = new System.Drawing.Size(167, 22);
            this.tbCost.TabIndex = 0;
                                                this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(383, 184);
            this.Controls.Add(this.tbCost);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.tbDestinationName);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.cbArrival);
            this.Controls.Add(this.cbDeparture);
            this.Controls.Add(this.btnCreate);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "DestinationCreate";
            this.Text = "Create Destination";
            this.Load += new System.EventHandler(this.DestinationCreate_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.ComboBox cbDeparture;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox tbDestinationName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnCreate;
        private System.Windows.Forms.ComboBox cbArrival;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox tbCost;
    }
}