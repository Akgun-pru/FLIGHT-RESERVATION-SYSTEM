﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightReservationSystem
{
    public partial class DestinationSelect : Form
    {
        string[] cities;
        public string SelectedDestination;
        public DestinationSelect()
        {
            InitializeComponent();
        }

        private void DestinationSelect_Load(object sender, EventArgs e)
        {
            cities = Database.GetColumn("SELECT name FROM city");
            cbFrom.Items.AddRange(cities);
            cbFrom.SelectedIndex = 0;
            string query = "SELECT destination.no FROM destination " +
              "INNER JOIN city departurecity ON destination.departureno=departurecity.no " +
              "INNER JOIN city arrivalcity ON arrivalcity.no=destination.arrivalno";
            DestinationList(query);
        }
        private string NoSeperate(string checkName)
        {
            return checkName.Split('_')[1];
        }
        private void cbFrom_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbTo.Items.Clear();
            cbTo.Items.AddRange(cities);
            cbTo.Items.Remove(cbFrom.SelectedItem);
            cbTo.SelectedIndex = 0;
        }
        private void ControlCopy(Panel kaynak, Panel hedef, Destination destination)
        {
            foreach (Control check in kaynak.Controls)
            {
                Control newc = null;
                switch (check)
                {
                    case LinkLabel _:
                        newc = new LinkLabel();
                        ((LinkLabel)newc).AutoSize = true;
                        break;
                    case Label _:
                        newc = new Label();
                        ((Label)newc).AutoSize = true;
                        break;
                    default:
                        newc = new Control();
                        break;
                }
                newc.Name = string.Concat(check.Name, "_", destination.no.ToString());
                newc.Size = check.Size;
                newc.Location = check.Location;
                newc.Font = check.Font;
                hedef.Controls.Add(newc);
                if (newc.Name.Contains("lblSeeAirlines"))
                {
                    newc.Click += AirlinesSee_Click; ;
                }
                else if (newc.Name.Contains("btnDestinationSelect"))
                {
                    newc.Click += DestinationSelect_Click; ;
                }
                if (newc.Name.Contains("lblDepartureCity"))
                    newc.Text = destination.departureCity;
                else if (newc.Name.Contains("lblArrivalCity"))
                    newc.Text = destination.arrivalCity;
                else if (newc.Name.Contains("lblDestinationName"))
                    newc.Text = destination.name;
                else
                    newc.Text = check.Text;
            }
        }

        private void DestinationSelect_Click(object sender, EventArgs e)
        {
            SelectedDestination = NoSeperate((((Control)sender).Name));
            DialogResult = DialogResult.OK;
        }

        private void AirlinesSee_Click(object sender, EventArgs e)
        {
         
        }

        private void ShowDestination(string no)
        {
            Destination destination = Database.GetDestination(int.Parse(no));
            if (destination != null)
            {
                Panel destinationPanel = new Panel();
                destinationPanel.Name = string.Concat("panel_", no.ToString());
                destinationPanel.Size = panel1.Size;
                destinationPanel.BackColor = panel1.BackColor;
                destinationPanel.Location = panel1.Location;
                ControlCopy(panel1, destinationPanel, destination);
                destinationPanel.Parent = flowLayoutPanel1;
            }
        }
        private void DestinationList(string query)
        {
            List<Control> toBeDeleted = new List<Control>();
            foreach (Control panel in flowLayoutPanel1.Controls)
            {
                if (panel is Panel && panel.Name != "panel1")
                {
                    toBeDeleted.Add(panel);
                }
            }
            foreach (Control toDelete in toBeDeleted)
            {
                flowLayoutPanel1.Controls.Remove(toDelete);
            }
            string[] destionations = Database.GetColumn(query);
            foreach (string destinationno in destionations)
            {
                ShowDestination(destinationno);
            }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string kalkisSehirNo = Database.GetNo("SELECT no FROM city WHERE name='" + cbFrom.Text + "'");
            string varisSehirNo = Database.GetNo("SELECT no FROM city WHERE name='" + cbTo.Text + "'");
            string query = "SELECT destination.no FROM destination " +
               "INNER JOIN city departurecity ON destination.departureno=departurecity.no " +
               "INNER JOIN city arrivalcity ON arrivalcity.no=destination.arrivalno" +
               "WHERE departurecity.no=" + kalkisSehirNo + " AND arrivalcity.no=" + varisSehirNo + "";
            DestinationList(query);
        }

        private void btnDestinationInsert_Click(object sender, EventArgs e)
        {
            new DestinationCreate().ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string query = "SELECT destination.no FROM destination " +
                "INNER JOIN city departurecity ON destination.departureno=departurecity.no " +
               "INNER JOIN city arrivalcity ON arrivalcity.no=destination.arrivalno";
            DestinationList(query);
        }

        private void btnDestinationSelect_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }
    }
}
