﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightReservationSystem
{
    public partial class StaffFlightList : Form
    {
        Employee employee;
        string kosul;
        string Durum;
        public StaffFlightList(string employeeNO, string Durum)
        {
            employee = Database.getEmployee(employeeNO);
            this.Durum = Durum;
            if (Durum == "Future")
            {
                kosul = "WHERE flight.departuredate > GETDATE()";
            }
            else
            {
                kosul = "WHERE flight.departuredate <= GETDATE()";
            }
            if (employee.type == "Host")
            {
                kosul += " AND hostno=" + employee.no;
            }
            else
            {
                kosul += " AND pilotno=" + employee.no;
            }
            InitializeComponent();
        }

        private void StaffFlightList_Load(object sender, EventArgs e)
        {
            lblBilgi.Text = Durum + " Flight List";
            flightTable.Columns.Add("a", "Departure Point");
            flightTable.Columns.Add("b", "Arrival Point");
            flightTable.Columns.Add("c", "Departure Date");
            flightTable.Columns.Add("d", "Arrival Date");
            flightTable.Columns.Add("e", "Airplane");
            string query = "SELECT flight.no FROM flight " +
               "INNER JOIN destination ON destination.no = flight.destinationno " +
               "INNER JOIN city departurecity ON destination.departureno=departurecity.no " +
               "INNER JOIN city arrivalcity ON arrivalcity.no=destination.arrivalno " +
               kosul;
            string[] flights = Database.GetColumn(query);
            foreach (string flightNo in flights)
            {
                Flight flight = Database.GetFlight(int.Parse(flightNo));
                flightTable.Rows.Add(new string[] { flight.departureCity, flight.arrivalCity, flight.departureDate, flight.arrivalDate, flight.airplane});
            }

        }

        private void lblBilgi_Click(object sender, EventArgs e)
        {

        }
    }
}
