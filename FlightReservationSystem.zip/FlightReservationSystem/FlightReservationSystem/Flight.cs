﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightReservationSystem
{
    public class Flight
    {
        public string departureCity, arrivalCity, departureDate, arrivalDate,pilot,host,airplane;
        public int flightNo;
        public double ticketCost=0;

        public Flight(string departureCity, string arrivalCity, string departureDate, string arrivalDate, double ticketCost,int flightNo,string pilot,string host,string airplane)
        {
            this.flightNo = flightNo;
            this.departureCity = departureCity;
            this.arrivalCity = arrivalCity;
            this.departureDate = departureDate;
            this.arrivalDate = arrivalDate;
            this.ticketCost = ticketCost;
            this.pilot = pilot;
            this.airplane= airplane;
            this.host= host;
        }
    }
}
