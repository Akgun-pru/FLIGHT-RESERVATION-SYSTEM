﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightReservationSystem
{
    public partial class FlightCreate : Form
    {
        string chosenDestination = "-1";
        public FlightCreate()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            DestinationSelect form = new DestinationSelect();
            if (form.ShowDialog() == DialogResult.OK)
            {
                chosenDestination = form.SelectedDestination;
                Destination choice = Database.GetDestination(int.Parse(chosenDestination));
                lblDestination.Text = choice.name;
            }
            else
            {
                chosenDestination = "-1";
                lblDestination.Text = "-------------------------";
            }
        }

        bool CheckDate()
        {
            if (dtDepartureDate.Value.Date > dtArrivalDate.Value.Date)
            {
                return false;
            }
            else if (dtDepartureDate.Value.Date == dtArrivalDate.Value.Date)
            {
                if (dtDepartureTime.Value >= dtArrivalTime.Value)
                {
                    return false;
                }
                else return true;
            }
            else return true;
        }
        private void button2_Click(object sender, EventArgs e)
        {
            if (chosenDestination != "-1" && CheckDate())
            {
                string pilotno = cbPilot.SelectedItem.ToString().Split('-')[0];
                string airplaneno = cbAirplane.SelectedItem.ToString().Split('-')[0];
                string hostno = cbHost.SelectedItem.ToString().Split('-')[0];
                string query = "INSERT INTO flight VALUES(@airplaneno,@pilotno,@hostno,@departuredate,@arrivaldate,@destinationno)";
                List<SqlParameter> parameters = new List<SqlParameter>();
                DateTime departureDate = dtDepartureDate.Value.Date;
                departureDate = departureDate.Date + new TimeSpan(dtDepartureTime.Value.Hour, dtDepartureTime.Value.Minute, 0);
                DateTime arrivalDate = dtArrivalDate.Value.Date;
                arrivalDate = arrivalDate.Date + new TimeSpan(dtArrivalTime.Value.Hour, dtArrivalTime.Value.Minute, 0);
                parameters.Add(new SqlParameter("@airplaneno", airplaneno));
                parameters.Add(new SqlParameter("@pilotno", pilotno));
                parameters.Add(new SqlParameter("@hostno", hostno));
                parameters.Add(new SqlParameter("@departuredate", departureDate));
                parameters.Add(new SqlParameter("@arrivaldate", arrivalDate));
                parameters.Add(new SqlParameter("@destinationno", chosenDestination));
                Database.ParameteredCommand(query, parameters);
                MessageBox.Show("Flight created!");
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid date or destination!");
            }
        }

        private void FlightCreate_Load(object sender, EventArgs e)
        {
            string[] pilotler = Database.GetColumn("SELECT CONCAT(no,'-',name,' ',surname) FROM employee WHERE typeno=1");
            string[] hostlar = Database.GetColumn("SELECT CONCAT(no,'-',name,' ',surname) FROM employee WHERE typeno=2");
            string[] ucakler = Database.GetColumn("SELECT CONCAT(airplane.no,'-',code,' ',airplanebrand.brand) FROM airplane " +
                "INNER JOIN airplanebrand ON airplanebrand.no=airplane.brandno");
            cbHost.Items.AddRange(hostlar);
            cbPilot.Items.AddRange(pilotler);
            cbAirplane.Items.AddRange(ucakler);
            try
            {
                cbAirplane.SelectedIndex = 0;
                cbHost.SelectedIndex = 0;
                cbPilot.SelectedIndex = 0;
            }
            catch (Exception)
            {
            }
        }
    }
}
