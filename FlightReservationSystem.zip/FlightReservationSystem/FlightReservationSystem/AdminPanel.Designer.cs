﻿namespace FlightReservationSystem
{
    partial class AdminPanel
    {
                                private System.ComponentModel.IContainer components = null;

                                        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

                                        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.btnListFlight = new System.Windows.Forms.Button();
            this.btnDestination = new System.Windows.Forms.Button();
            this.btnFlight = new System.Windows.Forms.Button();
            this.btnSell = new System.Windows.Forms.Button();
            this.btnEmployee = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 12);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(744, 39);
            this.button1.TabIndex = 0;
            this.button1.Text = "All Tables and Ticket Cancellation";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnListFlight
            // 
            this.btnListFlight.Location = new System.Drawing.Point(12, 181);
            this.btnListFlight.Name = "btnListFlight";
            this.btnListFlight.Size = new System.Drawing.Size(744, 56);
            this.btnListFlight.TabIndex = 4;
            this.btnListFlight.Text = "Flight List";
            this.btnListFlight.UseVisualStyleBackColor = true;
            this.btnListFlight.Click += new System.EventHandler(this.btnFlight_Click);
            // 
            // btnDestination
            // 
            this.btnDestination.Location = new System.Drawing.Point(384, 119);
            this.btnDestination.Name = "btnDestination";
            this.btnDestination.Size = new System.Drawing.Size(372, 56);
            this.btnDestination.TabIndex = 3;
            this.btnDestination.Text = "New Destination";
            this.btnDestination.UseVisualStyleBackColor = true;
            this.btnDestination.Click += new System.EventHandler(this.btnDestinationCreate_Click);
            // 
            // btnFlight
            // 
            this.btnFlight.Location = new System.Drawing.Point(12, 119);
            this.btnFlight.Name = "btnFlight";
            this.btnFlight.Size = new System.Drawing.Size(366, 56);
            this.btnFlight.TabIndex = 2;
            this.btnFlight.Text = "New Flight";
            this.btnFlight.UseVisualStyleBackColor = true;
            this.btnFlight.Click += new System.EventHandler(this.btnSeferCreate_Click);
            // 
            // btnSell
            // 
            this.btnSell.Location = new System.Drawing.Point(12, 57);
            this.btnSell.Name = "btnSell";
            this.btnSell.Size = new System.Drawing.Size(744, 56);
            this.btnSell.TabIndex = 1;
            this.btnSell.Text = "Sell Tickets";
            this.btnSell.UseVisualStyleBackColor = true;
            this.btnSell.Click += new System.EventHandler(this.btnSell_Click);
            // 
            // btnEmployee
            // 
            this.btnEmployee.Location = new System.Drawing.Point(12, 243);
            this.btnEmployee.Name = "btnEmployee";
            this.btnEmployee.Size = new System.Drawing.Size(744, 56);
            this.btnEmployee.TabIndex = 5;
            this.btnEmployee.Text = "New Employee";
            this.btnEmployee.UseVisualStyleBackColor = true;
            this.btnEmployee.Click += new System.EventHandler(this.button2_Click);
            // 
            // AdminPanel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(766, 313);
            this.Controls.Add(this.btnEmployee);
            this.Controls.Add(this.btnListFlight);
            this.Controls.Add(this.btnDestination);
            this.Controls.Add(this.btnFlight);
            this.Controls.Add(this.btnSell);
            this.Controls.Add(this.button1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "AdminPanel";
            this.Text = "Administrator";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button btnListFlight;
        private System.Windows.Forms.Button btnDestination;
        private System.Windows.Forms.Button btnFlight;
        private System.Windows.Forms.Button btnSell;
        private System.Windows.Forms.Button btnEmployee;
    }
}