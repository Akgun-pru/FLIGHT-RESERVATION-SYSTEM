﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightReservationSystem
{
    public partial class FlightSearch : Form
    {
        string[] cities;
        public FlightSearch()
        {
            InitializeComponent();
        }

        private void FlightSearch_Load(object sender, EventArgs e)
        {
            cities = Database.GetColumn("SELECT name FROM city");
            cbFrom.Items.AddRange(cities);
            cbFrom.SelectedIndex = 0;
        }
        private void ControlCopy(Panel kaynak, Panel hedef, Flight flight)
        {
            foreach (Control check in kaynak.Controls)
            {
                Control newc = null;
                switch (check)
                {
                    case Button _:
                        newc = new Button();
                        break;
                    case LinkLabel _:
                        newc = new LinkLabel();
                        ((LinkLabel)newc).AutoSize = true;
                        break;
                    case Label _:
                        newc = new Label();
                        ((Label)newc).AutoSize = true;
                        break;
                    default:
                        newc = new Control();
                        break;
                }
                newc.Name = string.Concat(check.Name, "_", flight.flightNo.ToString());
                newc.Size = check.Size;
                newc.Location = check.Location;
                newc.Font = check.Font;
                hedef.Controls.Add(newc);
                if (newc.Name.Contains("lblSeeAirlines"))
                {
                    newc.Click += AirlinesSee_Click;
                }
                else if (newc.Name.Contains("lblBuyTicket"))
                {
                    newc.Click += TicketBuy_Click;
                }
                else if (newc.Name.Contains("btnFlightDetail"))
                {
                    newc.Click += FlightDetail_Click;
                }
                if (newc.Name.Contains("lblDepartureCity"))
                    newc.Text = flight.departureCity;
                else if (newc.Name.Contains("lblArrivalCity"))
                    newc.Text = flight.arrivalCity;
                else if (newc.Name.Contains("lblDepartureDate"))
                    newc.Text = flight.departureDate;
                else if (newc.Name.Contains("lblArrivalDate"))
                    newc.Text = flight.arrivalDate;
                else if (newc.Name.Contains("lblTicketCost"))
                    newc.Text = flight.ticketCost.ToString() + "₺";
                else
                    newc.Text = string.Concat(check.Text);
            }
        }
        private string NoSeperate(string checkName)
        {
            return checkName.Split('_')[1];
        }
        private void FlightDetail_Click(object sender, EventArgs e)
        {
            string flightNo = NoSeperate(((Control)sender).Name);
            Flight flight = Database.GetFlight(int.Parse(flightNo));
            new FlightDetail(flight).ShowDialog();
        }
        private void TicketBuy_Click(object sender, EventArgs e)
        {
            string flightNo = NoSeperate(((Control)sender).Name);
            new ChooseSeat(int.Parse(flightNo)).Show();
        }

        private void AirlinesSee_Click(object sender, EventArgs e)
        {
           
        }

        private void FlightShow(int flightNo)
        {
            Flight flight = Database.GetFlight(flightNo);
            if (flight != null)
            {
                Panel flightPanel = new Panel();
                flightPanel.Name = string.Concat("panel_", flightNo.ToString());
                flightPanel.Size = panel1.Size;
                flightPanel.BackColor = panel1.BackColor;
                flightPanel.Location = panel1.Location;
                ControlCopy(panel1, flightPanel, flight);
                flightPanel.Parent = flowLayoutPanel1;
            }
        }

        private void cbFrom_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbTo.Items.Clear();
            cbTo.Items.AddRange(cities);
            cbTo.Items.Remove(cbFrom.SelectedItem);
            cbTo.SelectedIndex = 0;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            List<Control> toBeDeleted = new List<Control>();
            foreach (Control panel in flowLayoutPanel1.Controls)
            {
                if (panel is Panel && panel.Name != "panel1")
                {
                    toBeDeleted.Add(panel);
                }
            }
            foreach (Control toDelete in toBeDeleted)
            {
                flowLayoutPanel1.Controls.Remove(toDelete);
            }

            string kalkisSehirNo = Database.GetNo("SELECT no FROM city WHERE name='" + cbFrom.Text + "'");
            string varisSehirNo = Database.GetNo("SELECT no FROM city WHERE name='" + cbTo.Text + "'");
            string query = "SELECT flight.no FROM flight " +
                "INNER JOIN destination ON destination.no = flight.destinationno " +
                "INNER JOIN city departurecity ON destination.departureno=departurecity.no " +
                "INNER JOIN city arrivalcity ON arrivalcity.no=destination.arrivalno " +
                "WHERE departurecity.no=" + kalkisSehirNo + " AND arrivalcity.no=" + varisSehirNo + " AND flight.departuredate LIKE '%" + dtTarih.Value.ToString("yyyy-MM-dd") + "%'";
            string[] flightlar = Database.GetColumn(query);
            foreach (string flightNo in flightlar)
            {
                FlightShow(int.Parse(flightNo));
            }
        }

        private void btnFlightDetail_Click(object sender, EventArgs e)
        {

        }
    }
}
