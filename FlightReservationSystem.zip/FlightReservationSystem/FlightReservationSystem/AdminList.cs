﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightReservationSystem
{
    public partial class AdminList : Form
    {
        string choiseno = "-1";
        string colname = "-1";
        public AdminList()
        {
            InitializeComponent();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string tableName = cbTable.SelectedItem.ToString();
            dgv.Columns.Clear();
            string[] columns = Database.GetColumn("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '" + tableName + "'");
            Database.ListTable("SELECT * FROM " + tableName, dgv, columns);
            cbFilter.Items.Clear();
            cbFilter.Items.AddRange(columns);
            cbFilter.SelectedIndex = 0;
            choiseno = "-1";
            btnDelete.Enabled = false;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (colname != "-1" && choiseno != "-1")
            {
                string tableName = cbTable.SelectedItem.ToString();
                string[] columns = Database.GetColumn("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '" + tableName + "'");
                Database.RunCommand("DELETE FROM " + tableName + " WHERE " + colname + "=" + choiseno);
                Database.ListTable("SELECT * FROM " + tableName, dgv, columns);
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            if (cbFilter.SelectedIndex >= 0)
            {
                string tableName = cbTable.SelectedItem.ToString();
                string colname = cbFilter.SelectedItem.ToString();
                string[] columns = Database.GetColumn("SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_NAME = '" + tableName + "'");
                Database.ListTable("SELECT * FROM " + tableName + " WHERE " + colname + "='" + tbFilter.Text + "'", dgv, columns);
            }
        }

        private void Admin_List_Load(object sender, EventArgs e)
        {
            cbTable.SelectedIndex = 0;
        }

        private void dgv_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                choiseno = dgv.Rows[e.RowIndex].Cells[0].Value.ToString();
                colname = dgv.Columns[0].HeaderText;
                btnDelete.Enabled = true;
            }
            catch (Exception)
            {
                choiseno = "-1";
                colname = "-1";
                btnDelete.Enabled = false;
            }
        }

        private void cbFiltre_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
