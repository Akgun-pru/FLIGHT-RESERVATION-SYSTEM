﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightReservationSystem
{
    public partial class StaffGiris : Form
    {
        public StaffGiris()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string employeeNO = Database.GetNo("SELECT no FROM employee WHERE username='" + tbUsername.Text + "' AND password='" + tbPassword.Text + "'");
            if (employeeNO != "")
            {
                new StaffForm(employeeNO).Show();
                this.Hide();
            }
            else
            {
                MessageBox.Show("User Name/Password is wrong!");
            }
        }
    }
}
