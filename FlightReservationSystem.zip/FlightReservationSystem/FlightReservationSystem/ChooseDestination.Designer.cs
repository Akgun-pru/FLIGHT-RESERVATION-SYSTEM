﻿namespace FlightReservationSystem
{
    partial class DestinationSelect
    {
                                private System.ComponentModel.IContainer components = null;

                                        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

                                        private void InitializeComponent()
        {
            this.cbTo = new System.Windows.Forms.ComboBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cbFrom = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.panel1 = new System.Windows.Forms.Panel();
            this.btnDestinationSelect = new System.Windows.Forms.LinkLabel();
            this.label7 = new System.Windows.Forms.Label();
            this.lblArrivalCity = new System.Windows.Forms.Label();
            this.lblDestinationName = new System.Windows.Forms.Label();
            this.lblDepartureCity = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.btnDestinationInsert = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.flowLayoutPanel1.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // cbTo
            // 
            this.cbTo.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbTo.FormattingEnabled = true;
            this.cbTo.Location = new System.Drawing.Point(216, 61);
            this.cbTo.Margin = new System.Windows.Forms.Padding(5);
            this.cbTo.Name = "cbTo";
            this.cbTo.Size = new System.Drawing.Size(189, 24);
            this.cbTo.TabIndex = 4;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(290, 38);
            this.label2.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(26, 16);
            this.label2.TabIndex = 2;
            this.label2.Text = "To";
            // 
            // cbFrom
            // 
            this.cbFrom.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbFrom.FormattingEnabled = true;
            this.cbFrom.Location = new System.Drawing.Point(14, 61);
            this.cbFrom.Margin = new System.Windows.Forms.Padding(5);
            this.cbFrom.Name = "cbFrom";
            this.cbFrom.Size = new System.Drawing.Size(192, 24);
            this.cbFrom.TabIndex = 5;
            this.cbFrom.SelectedIndexChanged += new System.EventHandler(this.cbFrom_SelectedIndexChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(77, 38);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(42, 16);
            this.label1.TabIndex = 3;
            this.label1.Text = "From";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.flowLayoutPanel1.Controls.Add(this.panel1);
            this.flowLayoutPanel1.Location = new System.Drawing.Point(8, 95);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(510, 460);
            this.flowLayoutPanel1.TabIndex = 6;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.btnDestinationSelect);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.lblArrivalCity);
            this.panel1.Controls.Add(this.lblDestinationName);
            this.panel1.Controls.Add(this.lblDepartureCity);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(499, 82);
            this.panel1.TabIndex = 4;
            this.panel1.Visible = false;
            // 
            // btnDestinationSelect
            // 
            this.btnDestinationSelect.AutoSize = true;
            this.btnDestinationSelect.Location = new System.Drawing.Point(351, 26);
            this.btnDestinationSelect.Name = "btnDestinationSelect";
            this.btnDestinationSelect.Size = new System.Drawing.Size(91, 16);
            this.btnDestinationSelect.TabIndex = 6;
            this.btnDestinationSelect.TabStop = true;
            this.btnDestinationSelect.Text = "Select Dest.";
            this.btnDestinationSelect.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.btnDestinationSelect_LinkClicked);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 55);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "Arrival City:";
            // 
            // lblArrivalCity
            // 
            this.lblArrivalCity.AutoSize = true;
            this.lblArrivalCity.Location = new System.Drawing.Point(138, 55);
            this.lblArrivalCity.Name = "lblArrivalCity";
            this.lblArrivalCity.Size = new System.Drawing.Size(179, 16);
            this.lblArrivalCity.TabIndex = 0;
            this.lblArrivalCity.Text = "...........................................";
            // 
            // lblDestinationName
            // 
            this.lblDestinationName.AutoSize = true;
            this.lblDestinationName.Location = new System.Drawing.Point(138, 5);
            this.lblDestinationName.Name = "lblDestinationName";
            this.lblDestinationName.Size = new System.Drawing.Size(179, 16);
            this.lblDestinationName.TabIndex = 0;
            this.lblDestinationName.Text = "...........................................";
            // 
            // lblDepartureCity
            // 
            this.lblDepartureCity.AutoSize = true;
            this.lblDepartureCity.Location = new System.Drawing.Point(138, 26);
            this.lblDepartureCity.Name = "lblDepartureCity";
            this.lblDepartureCity.Size = new System.Drawing.Size(179, 16);
            this.lblDepartureCity.TabIndex = 0;
            this.lblDepartureCity.Text = "...........................................";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 5);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(134, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Destination Name:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 26);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Departure City:";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(407, 62);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(106, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "Search";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // btnDestinationInsert
            // 
            this.btnDestinationInsert.Location = new System.Drawing.Point(14, 8);
            this.btnDestinationInsert.Name = "btnDestinationInsert";
            this.btnDestinationInsert.Size = new System.Drawing.Size(499, 23);
            this.btnDestinationInsert.TabIndex = 7;
            this.btnDestinationInsert.Text = "Insert Destionation";
            this.btnDestinationInsert.UseVisualStyleBackColor = true;
            this.btnDestinationInsert.Click += new System.EventHandler(this.btnDestinationInsert_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(407, 36);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(104, 23);
            this.button2.TabIndex = 7;
            this.button2.Text = "Show All";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // DestinationSelect
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(523, 567);
            this.Controls.Add(this.btnDestinationInsert);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.cbTo);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.cbFrom);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "DestinationSelect";
            this.Text = "Select Destination";
            this.Load += new System.EventHandler(this.DestinationSelect_Load);
            this.flowLayoutPanel1.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cbTo;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cbFrom;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblArrivalCity;
        private System.Windows.Forms.Label lblDepartureCity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.LinkLabel btnDestinationSelect;
        private System.Windows.Forms.Label lblDestinationName;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btnDestinationInsert;
        private System.Windows.Forms.Button button2;
    }
}