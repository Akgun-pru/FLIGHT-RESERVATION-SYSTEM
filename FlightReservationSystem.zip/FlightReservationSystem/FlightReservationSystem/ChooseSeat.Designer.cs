﻿namespace FlightReservationSystem
{
    partial class ChooseSeat
    {
                                private System.ComponentModel.IContainer components = null;

                                        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

                                        private void InitializeComponent()
        {
            this.btnContinue = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.btnSelectim = new System.Windows.Forms.Button();
            this.btnBos = new System.Windows.Forms.Button();
            this.btnOccupied = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnContinue
            // 
            this.btnContinue.Enabled = false;
            this.btnContinue.Location = new System.Drawing.Point(10, 515);
            this.btnContinue.Name = "btnContinue";
            this.btnContinue.Size = new System.Drawing.Size(265, 38);
            this.btnContinue.TabIndex = 0;
            this.btnContinue.Text = "Continue";
            this.btnContinue.UseVisualStyleBackColor = true;
            this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(10, 559);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(265, 24);
            this.btnCancel.TabIndex = 0;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.ForeColor = System.Drawing.Color.White;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(10, 59);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Size = new System.Drawing.Size(265, 450);
            this.flowLayoutPanel1.TabIndex = 1;
            // 
            // btnSelectim
            // 
            this.btnSelectim.BackColor = System.Drawing.Color.Blue;
            this.btnSelectim.BackgroundImage = global::FlightReservationSystem.Properties.Resources.koltuk;
            this.btnSelectim.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnSelectim.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnSelectim.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnSelectim.Location = new System.Drawing.Point(163, 3);
            this.btnSelectim.Name = "btnSelectim";
            this.btnSelectim.Size = new System.Drawing.Size(61, 40);
            this.btnSelectim.TabIndex = 2;
            this.btnSelectim.Text = "CHOICE";
            this.btnSelectim.UseVisualStyleBackColor = false;
            this.btnSelectim.Click += new System.EventHandler(this.btnSelectim_Click);
            // 
            // btnBos
            // 
            this.btnBos.BackColor = System.Drawing.Color.Gray;
            this.btnBos.BackgroundImage = global::FlightReservationSystem.Properties.Resources.koltuk;
            this.btnBos.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnBos.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnBos.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnBos.Location = new System.Drawing.Point(100, 3);
            this.btnBos.Name = "btnBos";
            this.btnBos.Size = new System.Drawing.Size(61, 40);
            this.btnBos.TabIndex = 2;
            this.btnBos.Text = "VALID";
            this.btnBos.UseVisualStyleBackColor = false;
            // 
            // btnOccupied
            // 
            this.btnOccupied.BackColor = System.Drawing.Color.Red;
            this.btnOccupied.BackgroundImage = global::FlightReservationSystem.Properties.Resources.koltuk;
            this.btnOccupied.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.btnOccupied.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.btnOccupied.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btnOccupied.Location = new System.Drawing.Point(37, 3);
            this.btnOccupied.Name = "btnOccupied";
            this.btnOccupied.Size = new System.Drawing.Size(61, 40);
            this.btnOccupied.TabIndex = 2;
            this.btnOccupied.Text = "X";
            this.btnOccupied.UseVisualStyleBackColor = false;
            // 
            // ChooseSeat
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(286, 594);
            this.ControlBox = false;
            this.Controls.Add(this.btnSelectim);
            this.Controls.Add(this.btnBos);
            this.Controls.Add(this.btnOccupied);
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnContinue);
            this.Name = "ChooseSeat";
            this.Text = "Choose Seat";
            this.Load += new System.EventHandler(this.SeatSelectForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnContinue;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private System.Windows.Forms.Button btnOccupied;
        private System.Windows.Forms.Button btnBos;
        private System.Windows.Forms.Button btnSelectim;
    }
}