﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace FlightReservationSystem
{
    class Database
    {
        static SqlConnection con = new SqlConnection(@"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|\FlightReservation.mdf;Integrated Security=True");
        static SqlCommand cmd;
        static SqlDataReader dr;
        private static void open()
        {
            try
            {
                if (con.State == ConnectionState.Closed)
                {
                    con.Open();
                }
            }
            catch (Exception)
            {
                con.Close();
            }
        }
        private static void close()
        {
            try
            {
                if (con.State == ConnectionState.Open)
                {
                    con.Close();
                }
            }
            catch (Exception)
            {
                con.Close();
            }
        }
        public static bool ParameteredCommand(string command, List<SqlParameter> parameters)
        {
            try
            {
                open(); cmd = new SqlCommand(command, con); cmd.Parameters.AddRange(parameters.ToArray()); int result = cmd.ExecuteNonQuery(); close(); if (result > 0)
                {
                    return true;
                }
                else return false;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message); close(); return false;
            }
        }
        public static bool RunCommand(string command)
        {
            try
            {
                open(); cmd = new SqlCommand(command, con); int result = cmd.ExecuteNonQuery(); close(); if (result > 0)
                {
                    return true;
                }
                else return false;
            }
            catch (Exception)
            {
                close(); return false;
            }
        }
        public static string GetNo(string command)
        {
            string NO = "";
            open(); cmd = new SqlCommand(command, con); dr = cmd.ExecuteReader(); if (dr.Read())
            {
                NO = dr[0].ToString();
            }
            close(); return NO;
        }
        public static void ListTable(string command, DataGridView dgv, string[] headers)
        {
            open(); dgv.Rows.Clear(); dgv.Columns.Clear(); foreach (string header in headers)
            {
                dgv.Columns.Add(header, header);
            }
            cmd = new SqlCommand(command, con); 
            dr = cmd.ExecuteReader(); 
            while (dr.Read())
            {
                string[] columns = new string[dr.FieldCount]; for (int i = 0; i < dr.FieldCount; i++)
                {
                    columns[i] = dr[i].ToString();
                }
                dgv.Rows.Add(columns);
            }
            close();
        }
        public static string[] GetColumn(string command)
        {
            List<string> satirlar = new List<string>(); open(); cmd = new SqlCommand(command, con); dr = cmd.ExecuteReader(); while (dr.Read())
            {
                satirlar.Add(dr[0].ToString());
            }
            close(); return satirlar.ToArray();
        }
        public static Flight GetFlight(int flightNo)
        {
            open(); string query = "SELECT departurecity.name,arrivalcity.name," +
    "FORMAT(flight.departuredate, 'dd/MM/yyyy hh:mm'),FORMAT(flight.arrivaldate, 'dd/MM/yyyy hh:mm')," +
    "destination.cost,flight.no," +
    " CONCAT(pilot.name,' ',pilot.surname),CONCAT(host.name,' ',host.surname)," +
    "CONCAT(airplanebrand.brand,' ',airplane.code) FROM flight  " +
    "INNER JOIN employee pilot ON pilot.no=flight.pilotno " +
    "INNER JOIN employee host ON host.no=flight.hostno " +
    "INNER JOIN airplane ON airplane.no=flight.airplaneno " +
    "INNER JOIN airplanebrand ON airplane.brandno=airplanebrand.no " +
    "INNER JOIN destination ON flight.destinationno = destination.no  " +
    "INNER JOIN city departurecity ON departurecity.no = destination.departureno  " +
    "INNER JOIN city arrivalcity ON arrivalcity.no = destination.arrivalno " +
    "WHERE flight.no=" + flightNo + ""; cmd = new SqlCommand(query, con); dr = cmd.ExecuteReader(); Flight flight = null; if (dr.Read())
            {
                flight = new Flight(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(), dr[3].ToString(),
                    double.Parse(dr[4].ToString()), int.Parse(dr[5].ToString()), dr[6].ToString(), dr[7].ToString(), dr[8].ToString());
            }
            close(); return flight;
        }
        public static Destination GetDestination(int destinationno)
        {
            open(); string query = "SELECT destination.no,destination.destinationname,departurecity.name,arrivalcity.name" +
    " FROM destination " +
    "INNER JOIN city departurecity ON departurecity.no = destination.departureno " +
    "INNER JOIN city arrivalcity ON arrivalcity.no = destination.arrivalno  " +
    "WHERE destination.no=" + destinationno;
            cmd = new SqlCommand(query, con); dr = cmd.ExecuteReader(); Destination destination = null; if (dr.Read())
            {
                destination = new Destination(dr[0].ToString(), dr[1].ToString(),
                    dr[2].ToString(), dr[3].ToString());
            }
            close(); return destination;
        }
        public static bool IsSeatEmpty(int flightNo, int seatno)
        {
            open(); string query = "SELECT no FROM ticket WHERE flightno=" + flightNo + " AND seatno=" + seatno; cmd = new SqlCommand(query, con); dr = cmd.ExecuteReader(); bool result = false; if (dr.Read())
            {
                result = true;
            }
            close(); return result;
        }
        public static Customer getCustomer(string idnumber)
        {
            Customer search = null; open(); string query = "SELECT * FROM customer WHERE idnumber='" + idnumber + "'"; cmd = new SqlCommand(query, con); dr = cmd.ExecuteReader(); if (dr.Read())
            {
                search = new Customer(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(),
                    dr[3].ToString(), dr[4].ToString(), dr[5].ToString(),
                    dr[6].ToString(), dr[7].ToString(), dr[8].ToString());
            }
            close(); return search;
        }
        public static Employee getEmployee(string no)
        {
            Employee search = null; open(); string query = "SELECT employee.no,name,surname,email,phone,address,username,password,employteetype.type FROM employee INNER JOIN employteetype ON employee.typeno=employteetype.no WHERE employee.no=" + no;
            cmd = new SqlCommand(query, con); dr = cmd.ExecuteReader(); if (dr.Read())
            {
                search = new Employee(dr[0].ToString(), dr[1].ToString(), dr[2].ToString(),
                    dr[3].ToString(), dr[4].ToString(), dr[5].ToString(),
                    dr[6].ToString(), dr[7].ToString(), dr[8].ToString());
            }
            close(); return search;
        }
    }
}
