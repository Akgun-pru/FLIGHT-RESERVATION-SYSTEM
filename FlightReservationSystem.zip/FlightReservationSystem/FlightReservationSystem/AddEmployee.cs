﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace FlightReservationSystem
{
    public partial class AddEmployee : Form
    {
        public AddEmployee()
        {
            InitializeComponent();
        }

        private void AddEmployee_Load(object sender, EventArgs e)
        {
            cbType.SelectedIndex = 0;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (tbName.Text != "" && tbSurname.Text != "" && tbUname.Text != "" && tbPassword.Text != "")
            {
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@name", tbName.Text));
                parameters.Add(new SqlParameter("@surname", tbSurname.Text));
                parameters.Add(new SqlParameter("@email", tbEmail.Text));
                parameters.Add(new SqlParameter("@phone", tbPhone.Text));
                parameters.Add(new SqlParameter("@address", tbAddress.Text));
                parameters.Add(new SqlParameter("@uname", tbUname.Text));
                parameters.Add(new SqlParameter("@password", tbPassword.Text));
                parameters.Add(new SqlParameter("@type", cbType.SelectedItem.ToString().Split('-')[0]));
                if (Database.ParameteredCommand("INSERT INTO employee VALUES(@name,@surname,@email,@phone,@address,@uname,@password,@type)", parameters))
                {
                    MessageBox.Show("Record inserted!");
                    this.Close();
                }
                else MessageBox.Show("Please check entered data.");

            }
            else MessageBox.Show("Please fill all fields");
        }
    }
}
