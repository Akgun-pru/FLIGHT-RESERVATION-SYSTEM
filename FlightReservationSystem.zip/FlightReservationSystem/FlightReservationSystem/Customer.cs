﻿namespace FlightReservationSystem
{
    public class Customer
    {
        public string no, idnumber, name, surname, phone, address, dateofbirth, email, gender;

        public Customer(string no, string idnumber, string name, string surname, string phone, string address, string dateofbirth, string email, string gender)
        {
            this.no = no;
            this.idnumber = idnumber;
            this.name= name;
            this.surname = surname;
            this.phone = phone;
            this.address= address;
            this.dateofbirth = dateofbirth;
            this.email = email;
            this.gender = gender;
        }
    }
}