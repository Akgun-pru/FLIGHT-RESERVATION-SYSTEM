﻿namespace FlightReservationSystem
{
    partial class StaffForm
    {
                                private System.ComponentModel.IContainer components = null;

                                        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

                                        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.btnFutureFlight = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.lblSeeev = new System.Windows.Forms.Label();
            this.lblNameres = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblEposta = new System.Windows.Forms.Label();
            this.lblNameSoyad = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.lblTime = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.btnGecmisFlight = new System.Windows.Forms.Button();
            this.btnSell = new System.Windows.Forms.Button();
            this.btnFlightCreate = new System.Windows.Forms.Button();
            this.btnAirplane = new System.Windows.Forms.Button();
            this.btnDestinationCreate = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
                                                this.btnFutureFlight.Enabled = false;
            this.btnFutureFlight.Location = new System.Drawing.Point(15, 123);
            this.btnFutureFlight.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnFutureFlight.Name = "btnFutureFlight";
            this.btnFutureFlight.Size = new System.Drawing.Size(366, 49);
            this.btnFutureFlight.TabIndex = 0;
            this.btnFutureFlight.Text = "Future Flights";
            this.btnFutureFlight.UseVisualStyleBackColor = true;
            this.btnFutureFlight.Click += new System.EventHandler(this.button1_Click);
                                                this.groupBox1.Controls.Add(this.lblSeeev);
            this.groupBox1.Controls.Add(this.lblNameres);
            this.groupBox1.Controls.Add(this.lblPhone);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.lblEposta);
            this.groupBox1.Controls.Add(this.lblNameSoyad);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 29);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(747, 87);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Staff About";
                                                this.lblSeeev.AutoSize = true;
            this.lblSeeev.Location = new System.Drawing.Point(576, 25);
            this.lblSeeev.Name = "lblSeeev";
            this.lblSeeev.Size = new System.Drawing.Size(32, 16);
            this.lblSeeev.TabIndex = 0;
            this.lblSeeev.Text = "-----";
                                                this.lblNameres.AutoSize = true;
            this.lblNameres.Location = new System.Drawing.Point(341, 53);
            this.lblNameres.Name = "lblNameres";
            this.lblNameres.Size = new System.Drawing.Size(32, 16);
            this.lblNameres.TabIndex = 0;
            this.lblNameres.Text = "-----";
                                                this.lblPhone.AutoSize = true;
            this.lblPhone.Location = new System.Drawing.Point(339, 25);
            this.lblPhone.Name = "lblPhone";
            this.lblPhone.Size = new System.Drawing.Size(32, 16);
            this.lblPhone.TabIndex = 0;
            this.lblPhone.Text = "-----";
                                                this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(507, 25);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(37, 16);
            this.label5.TabIndex = 0;
            this.label5.Text = "Job:";
                                                this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(272, 53);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(65, 16);
            this.label9.TabIndex = 0;
            this.label9.Text = "Address";
                                                this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(270, 25);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(55, 16);
            this.label3.TabIndex = 0;
            this.label3.Text = "Phone:";
                                                this.lblEposta.AutoSize = true;
            this.lblEposta.Location = new System.Drawing.Point(134, 53);
            this.lblEposta.Name = "lblEposta";
            this.lblEposta.Size = new System.Drawing.Size(32, 16);
            this.lblEposta.TabIndex = 0;
            this.lblEposta.Text = "-----";
                                                this.lblNameSoyad.AutoSize = true;
            this.lblNameSoyad.Location = new System.Drawing.Point(132, 25);
            this.lblNameSoyad.Name = "lblNameSoyad";
            this.lblNameSoyad.Size = new System.Drawing.Size(32, 16);
            this.lblNameSoyad.TabIndex = 0;
            this.lblNameSoyad.Text = "-----";
                                                this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(11, 53);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(55, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "E-Mail:";
                                                this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(9, 25);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(117, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Name Surname:";
                                                this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 8);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(92, 16);
            this.label2.TabIndex = 1;
            this.label2.Text = "Date - Time:";
                                                this.lblTime.AutoSize = true;
            this.lblTime.Location = new System.Drawing.Point(114, 8);
            this.lblTime.Name = "lblTime";
            this.lblTime.Size = new System.Drawing.Size(71, 16);
            this.lblTime.TabIndex = 1;
            this.lblTime.Text = "00000000";
                                                this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
                                                this.btnGecmisFlight.Enabled = false;
            this.btnGecmisFlight.Location = new System.Drawing.Point(387, 123);
            this.btnGecmisFlight.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.btnGecmisFlight.Name = "btnGecmisFlight";
            this.btnGecmisFlight.Size = new System.Drawing.Size(372, 49);
            this.btnGecmisFlight.TabIndex = 1;
            this.btnGecmisFlight.Text = "Past Flights";
            this.btnGecmisFlight.UseVisualStyleBackColor = true;
            this.btnGecmisFlight.Click += new System.EventHandler(this.button2_Click);
                                                this.btnSell.Enabled = false;
            this.btnSell.Location = new System.Drawing.Point(15, 179);
            this.btnSell.Name = "btnSell";
            this.btnSell.Size = new System.Drawing.Size(744, 56);
            this.btnSell.TabIndex = 2;
            this.btnSell.Text = "Ticket Sales Form";
            this.btnSell.UseVisualStyleBackColor = true;
            this.btnSell.Click += new System.EventHandler(this.btnSell_Click);
                                                this.btnFlightCreate.Enabled = false;
            this.btnFlightCreate.Location = new System.Drawing.Point(15, 241);
            this.btnFlightCreate.Name = "btnFlightCreate";
            this.btnFlightCreate.Size = new System.Drawing.Size(366, 56);
            this.btnFlightCreate.TabIndex = 3;
            this.btnFlightCreate.Text = "Create new Flight";
            this.btnFlightCreate.UseVisualStyleBackColor = true;
            this.btnFlightCreate.Click += new System.EventHandler(this.btnFlightCreate_Click);
                                                this.btnAirplane.Enabled = false;
            this.btnAirplane.Location = new System.Drawing.Point(15, 303);
            this.btnAirplane.Name = "btnAirplane";
            this.btnAirplane.Size = new System.Drawing.Size(744, 56);
            this.btnAirplane.TabIndex = 5;
            this.btnAirplane.Text = "List and Edit Flights";
            this.btnAirplane.UseVisualStyleBackColor = true;
            this.btnAirplane.Click += new System.EventHandler(this.btnAirplane_Click);
                                                this.btnDestinationCreate.Enabled = false;
            this.btnDestinationCreate.Location = new System.Drawing.Point(387, 241);
            this.btnDestinationCreate.Name = "btnDestinationCreate";
            this.btnDestinationCreate.Size = new System.Drawing.Size(366, 56);
            this.btnDestinationCreate.TabIndex = 4;
            this.btnDestinationCreate.Text = "Create Destination";
            this.btnDestinationCreate.UseVisualStyleBackColor = true;
            this.btnDestinationCreate.Click += new System.EventHandler(this.btnDestinationCreate_Click);
                                                this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(771, 367);
            this.Controls.Add(this.btnAirplane);
            this.Controls.Add(this.btnDestinationCreate);
            this.Controls.Add(this.btnFlightCreate);
            this.Controls.Add(this.btnSell);
            this.Controls.Add(this.lblTime);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.btnGecmisFlight);
            this.Controls.Add(this.btnFutureFlight);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "StaffForm";
            this.Text = "Staff";
            this.Load += new System.EventHandler(this.StaffForm_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnFutureFlight;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label lblSeeev;
        private System.Windows.Forms.Label lblNameres;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblEposta;
        private System.Windows.Forms.Label lblNameSoyad;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label lblTime;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Button btnGecmisFlight;
        private System.Windows.Forms.Button btnSell;
        private System.Windows.Forms.Button btnFlightCreate;
        private System.Windows.Forms.Button btnAirplane;
        private System.Windows.Forms.Button btnDestinationCreate;
    }
}