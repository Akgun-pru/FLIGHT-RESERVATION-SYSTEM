﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace FlightReservationSystem
{
    public partial class buyTicketForm : Form
    {
        int flightNo, seatno;
        string[] airlines;
        Flight flight;
        Customer customer;
        double total = 0;
        public buyTicketForm(int flightNo, int seatno)
        {
            this.flightNo = flightNo;
            this.seatno = seatno;
            flight = Database.GetFlight(flightNo);
            total = flight.ticketCost;
            InitializeComponent();
        }
        private void btnContinue_Click(object sender, EventArgs e)
        {
            if (tbIdentity.Text.Length == 11)
            {
                customer = Database.getCustomer(tbIdentity.Text);
                if (customer == null)
                {
                    panelPersonal.Enabled = true;
                    MessageBox.Show("No record found, please create new one");
                }
                else
                {
                    tbName.Text = customer.name;
                    tbSurname.Text = customer.surname;
                    tbAddress.Text = customer.address;
                    tbPhone.Text = customer.phone;
                    tbEmail.Text = customer.email;
                    if (customer.gender == "Male")
                    {
                        radioMale.Checked = true;
                    }
                    else radioFemale.Checked = true;
                    panelPersonal.Enabled = false;
                    btnApproval.Enabled = true;
                }
            }
            else
            {
                MessageBox.Show("Identity length should be 11");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (tbName.Text != "" && tbSurname.Text != "" && tbPhone.Text != "" && tbEmail.Text != "" && tbAddress.Text != "")
            {
                string query = "INSERT INTO customer VALUES(@idnumber,@name,@surname,@phone,@address,@dateofbirth,@email,@gender)";
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@idnumber", tbIdentity.Text));
                parameters.Add(new SqlParameter("@name", tbName.Text));
                parameters.Add(new SqlParameter("@surname", tbSurname.Text));
                parameters.Add(new SqlParameter("@phone", tbPhone.Text));
                parameters.Add(new SqlParameter("@address", tbAddress.Text));
                parameters.Add(new SqlParameter("@dateofbirth", dtBirth.Value));
                parameters.Add(new SqlParameter("@email", tbEmail.Text));
                parameters.Add(new SqlParameter("@gender", radioMale.Checked ? radioMale.Text : radioFemale.Text));
                Database.ParameteredCommand(query, parameters);
                MessageBox.Show("Registration done, you can continue.");
                btnContinue.Enabled = false;
                panelPersonal.Enabled = false;
                customer = Database.getCustomer(tbIdentity.Text);
                btnApproval.Enabled = true;
            }
            else MessageBox.Show("Please fill all fields.");
        }
     

        private void btnApproval_Click(object sender, EventArgs e)
        {
            if (customer != null && total != 0)
            {
                string query = "INSERT INTO ticket VALUES(@customerno,@flightNo,GETDATE()" +
                    ",@seatno,@cost)";
                List<SqlParameter> parameters = new List<SqlParameter>();
                parameters.Add(new SqlParameter("@customerno", customer.no));
                parameters.Add(new SqlParameter("@flightNo", flightNo));
                parameters.Add(new SqlParameter("@seatno", seatno));
                parameters.Add(new SqlParameter("@cost", total));
                Database.ParameteredCommand(query, parameters);
                MessageBox.Show("Seat reserved, you can track your flight from Tickets page.");
                this.Close();
            }
        }

        private void TicketBuyForm_Load(object sender, EventArgs e)
        {
            lblSeatNo.Text = seatno.ToString();
            lblTicketCost.Text = flight.ticketCost + "₺";
            lblHost.Text = flight.host;
            lblDepartureDate.Text = flight.departureDate;
            lblDepartureCity.Text = flight.departureCity;
            lblAirplane.Text = flight.airplane;
            lblPilot.Text = flight.pilot;
            lblArrivalDate.Text = flight.arrivalDate;
            lblArrivalCity.Text = flight.arrivalCity;
            airlines = Database.GetColumn(
                "SELECT DISTINCT CONCAT(city.name,' - ',destination.destinationname) FROM destination " +
                "INNER JOIN flight ON flight.destinationno=destination.no " +
                "INNER JOIN city ON city.no=destination.departureno " +
                "WHERE flight.no=" + flightNo);
        }
    }
}
