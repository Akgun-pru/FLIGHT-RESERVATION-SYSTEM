﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightReservationSystem
{
    public partial class TicketsForm : Form
    {
        public TicketsForm()
        {
            InitializeComponent();
        }

        private void TicketsForm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string query = "SELECT CONCAT(customer.name,' ',customer.surname) as 'Name Surname',flight.departuredate as 'Departure Date'," +
                "flight.arrivaldate as 'Arrival Date', departurecity.name as 'Departure City'," +
                "arrivalcity.name as 'Arrival City',ticket.cost as 'Amount',ticket.seatno as 'Seat'," +
                "createdatetime as 'Date Bought' FROM ticket " +
                "INNER JOIN flight ON flight.no=ticket.flightno " +
                "INNER JOIN destination ON destination.no=flight.destinationno " +
                "INNER JOIN city departurecity ON departurecity.no = destination.departureno " +
                "INNER JOIN city arrivalcity ON arrivalcity.no=destination.arrivalno " +
                "INNER JOIN customer ON customer.no=ticket.customerno WHERE customer.idnumber='" + tbIdentity.Text + "'";
            Database.ListTable(query, biletTablo, new string[] {"Name Surname","Departure Date","Arrival Date",
            "Departure City","Arrival City","Amount","Seat No","Date"});
        }
    }
}
