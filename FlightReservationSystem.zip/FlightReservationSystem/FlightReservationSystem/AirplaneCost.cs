﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightReservationSystem
{
    public partial class AirplaneCosts : Form
    {
        string airNo;
        public AirplaneCosts(string airNo)
        {
            this.airNo = airNo;
            InitializeComponent();
        }
        private void CostsList()
        {
            Database.ListTable("SELECT airplane.code,airplanecost.cost,airplanecost.description FROM airplane " +
                "INNER JOIN airplanecost ON airplane.no = airplanecost.airplaneno", dtCosts, new string[] { "Code", "Amount", "Description" });
        }
        private void AirplaneCosts_Load(object sender, EventArgs e)
        {
            CostsList();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (tbAmount.Text != "" && tbDescription.Text != "")
            {
                Database.RunCommand("INSERT INTO airplanecost VALUES(" + airNo + ",'" + tbDescription.Text + "'," + tbAmount.Text + ")");
                CostsList();
                MessageBox.Show("Costs inserted.");

            }
        }
    }
}
