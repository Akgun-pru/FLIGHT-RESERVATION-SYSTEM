﻿namespace FlightReservationSystem
{
    public class Destination
    {
        public string no,name,departureCity,arrivalCity,stopCount;

        public Destination(string no,string name, string departureCity, string arrivalCity)
        {
            this.no = no;
            this.name= name;
            this.departureCity = departureCity;
            this.arrivalCity = arrivalCity;
        }
    }
}