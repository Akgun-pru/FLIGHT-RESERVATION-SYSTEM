﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FlightReservationSystem
{
    class Employee
    {
        public string no, name, surname, email, phone, address, username, password, type;
        public Employee(string no, string name, string surname, string email, string phone, string address, string username, string password, string type)
        {
            this.no = no;
            this.name = name;
            this.surname = surname;
            this.email = email;
            this.phone = phone;
            this.address = address;
            this.username = username;
            this.password = password;
            this.type = type;
        }
    }
}
