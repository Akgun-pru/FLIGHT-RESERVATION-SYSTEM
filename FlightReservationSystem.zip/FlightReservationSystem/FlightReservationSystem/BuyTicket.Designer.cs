﻿namespace FlightReservationSystem
{
    partial class buyTicketForm
    {
                                private System.ComponentModel.IContainer components = null;

                                        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

                                        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblSeatNo = new System.Windows.Forms.Label();
            this.lblTicketCost = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.lblAirplane = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.lblHost = new System.Windows.Forms.Label();
            this.lblPilot = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblDepartureDate = new System.Windows.Forms.Label();
            this.lblArrivalDate = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblArrivalCity = new System.Windows.Forms.Label();
            this.lblDepartureCity = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.panelPersonal = new System.Windows.Forms.GroupBox();
            this.dtBirth = new System.Windows.Forms.DateTimePicker();
            this.radioFemale = new System.Windows.Forms.RadioButton();
            this.button2 = new System.Windows.Forms.Button();
            this.radioMale = new System.Windows.Forms.RadioButton();
            this.label13 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.tbAddress = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.tbEmail = new System.Windows.Forms.TextBox();
            this.tbPhone = new System.Windows.Forms.TextBox();
            this.tbSurname = new System.Windows.Forms.TextBox();
            this.tbName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.tbIdentity = new System.Windows.Forms.TextBox();
            this.btnContinue = new System.Windows.Forms.Button();
            this.btnApproval = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panelPersonal.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.panel1.Controls.Add(this.lblSeatNo);
            this.panel1.Controls.Add(this.lblTicketCost);
            this.panel1.Controls.Add(this.label16);
            this.panel1.Controls.Add(this.lblAirplane);
            this.panel1.Controls.Add(this.label20);
            this.panel1.Controls.Add(this.lblHost);
            this.panel1.Controls.Add(this.lblPilot);
            this.panel1.Controls.Add(this.label8);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.lblDepartureDate);
            this.panel1.Controls.Add(this.lblArrivalDate);
            this.panel1.Controls.Add(this.label12);
            this.panel1.Controls.Add(this.label11);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.lblArrivalCity);
            this.panel1.Controls.Add(this.lblDepartureCity);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Location = new System.Drawing.Point(14, 18);
            this.panel1.Margin = new System.Windows.Forms.Padding(3, 5, 3, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(883, 152);
            this.panel1.TabIndex = 6;
            // 
            // lblSeatNo
            // 
            this.lblSeatNo.AutoSize = true;
            this.lblSeatNo.Location = new System.Drawing.Point(751, 50);
            this.lblSeatNo.Name = "lblSeatNo";
            this.lblSeatNo.Size = new System.Drawing.Size(15, 16);
            this.lblSeatNo.TabIndex = 4;
            this.lblSeatNo.Text = "0";
            // 
            // lblTicketCost
            // 
            this.lblTicketCost.AutoSize = true;
            this.lblTicketCost.Location = new System.Drawing.Point(751, 18);
            this.lblTicketCost.Name = "lblTicketCost";
            this.lblTicketCost.Size = new System.Drawing.Size(23, 16);
            this.lblTicketCost.TabIndex = 4;
            this.lblTicketCost.Text = "0₺";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(653, 18);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(93, 16);
            this.label16.TabIndex = 5;
            this.label16.Text = "Ticket Cost: ";
            // 
            // lblAirplane
            // 
            this.lblAirplane.AutoSize = true;
            this.lblAirplane.Location = new System.Drawing.Point(454, 112);
            this.lblAirplane.Name = "lblAirplane";
            this.lblAirplane.Size = new System.Drawing.Size(187, 16);
            this.lblAirplane.TabIndex = 1;
            this.lblAirplane.Text = ".............................................";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(653, 50);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(67, 16);
            this.label20.TabIndex = 5;
            this.label20.Text = "Seat No:";
            // 
            // lblHost
            // 
            this.lblHost.AutoSize = true;
            this.lblHost.Location = new System.Drawing.Point(454, 82);
            this.lblHost.Name = "lblHost";
            this.lblHost.Size = new System.Drawing.Size(187, 16);
            this.lblHost.TabIndex = 1;
            this.lblHost.Text = ".............................................";
            // 
            // lblPilot
            // 
            this.lblPilot.AutoSize = true;
            this.lblPilot.Location = new System.Drawing.Point(454, 50);
            this.lblPilot.Name = "lblPilot";
            this.lblPilot.Size = new System.Drawing.Size(187, 16);
            this.lblPilot.TabIndex = 1;
            this.lblPilot.Text = ".............................................";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(340, 112);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(94, 16);
            this.label8.TabIndex = 1;
            this.label8.Text = "Flight Code :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(340, 82);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 16);
            this.label3.TabIndex = 1;
            this.label3.Text = "Host :";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(340, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 16);
            this.label1.TabIndex = 1;
            this.label1.Text = "Pilot :";
            // 
            // lblDepartureDate
            // 
            this.lblDepartureDate.AutoSize = true;
            this.lblDepartureDate.Location = new System.Drawing.Point(117, 82);
            this.lblDepartureDate.Name = "lblDepartureDate";
            this.lblDepartureDate.Size = new System.Drawing.Size(179, 16);
            this.lblDepartureDate.TabIndex = 0;
            this.lblDepartureDate.Text = "...........................................";
            // 
            // lblArrivalDate
            // 
            this.lblArrivalDate.AutoSize = true;
            this.lblArrivalDate.Location = new System.Drawing.Point(117, 112);
            this.lblArrivalDate.Name = "lblArrivalDate";
            this.lblArrivalDate.Size = new System.Drawing.Size(179, 16);
            this.lblArrivalDate.TabIndex = 0;
            this.lblArrivalDate.Text = "...........................................";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(16, 82);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(117, 16);
            this.label12.TabIndex = 0;
            this.label12.Text = "Departure Date:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(16, 112);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(89, 16);
            this.label11.TabIndex = 0;
            this.label11.Text = "Arrival Date";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(16, 50);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(86, 16);
            this.label7.TabIndex = 0;
            this.label7.Text = "Arrival City:";
            // 
            // lblArrivalCity
            // 
            this.lblArrivalCity.AutoSize = true;
            this.lblArrivalCity.Location = new System.Drawing.Point(117, 50);
            this.lblArrivalCity.Name = "lblArrivalCity";
            this.lblArrivalCity.Size = new System.Drawing.Size(179, 16);
            this.lblArrivalCity.TabIndex = 0;
            this.lblArrivalCity.Text = "...........................................";
            // 
            // lblDepartureCity
            // 
            this.lblDepartureCity.AutoSize = true;
            this.lblDepartureCity.Location = new System.Drawing.Point(117, 18);
            this.lblDepartureCity.Name = "lblDepartureCity";
            this.lblDepartureCity.Size = new System.Drawing.Size(179, 16);
            this.lblDepartureCity.TabIndex = 0;
            this.lblDepartureCity.Text = "...........................................";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(16, 18);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(110, 16);
            this.label4.TabIndex = 0;
            this.label4.Text = "Departure City:";
            // 
            // panelPersonal
            // 
            this.panelPersonal.Controls.Add(this.dtBirth);
            this.panelPersonal.Controls.Add(this.radioFemale);
            this.panelPersonal.Controls.Add(this.button2);
            this.panelPersonal.Controls.Add(this.radioMale);
            this.panelPersonal.Controls.Add(this.label13);
            this.panelPersonal.Controls.Add(this.label9);
            this.panelPersonal.Controls.Add(this.label15);
            this.panelPersonal.Controls.Add(this.label14);
            this.panelPersonal.Controls.Add(this.label10);
            this.panelPersonal.Controls.Add(this.tbAddress);
            this.panelPersonal.Controls.Add(this.label5);
            this.panelPersonal.Controls.Add(this.tbEmail);
            this.panelPersonal.Controls.Add(this.tbPhone);
            this.panelPersonal.Controls.Add(this.tbSurname);
            this.panelPersonal.Controls.Add(this.tbName);
            this.panelPersonal.Enabled = false;
            this.panelPersonal.Location = new System.Drawing.Point(15, 214);
            this.panelPersonal.Name = "panelPersonal";
            this.panelPersonal.Size = new System.Drawing.Size(883, 110);
            this.panelPersonal.TabIndex = 7;
            this.panelPersonal.TabStop = false;
            this.panelPersonal.Text = "Personal Information";
            // 
            // dtBirth
            // 
            this.dtBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtBirth.Location = new System.Drawing.Point(511, 52);
            this.dtBirth.Name = "dtBirth";
            this.dtBirth.Size = new System.Drawing.Size(123, 22);
            this.dtBirth.TabIndex = 15;
            // 
            // radioFemale
            // 
            this.radioFemale.AutoSize = true;
            this.radioFemale.Location = new System.Drawing.Point(430, 55);
            this.radioFemale.Name = "radioFemale";
            this.radioFemale.Size = new System.Drawing.Size(77, 20);
            this.radioFemale.TabIndex = 14;
            this.radioFemale.Text = "Female";
            this.radioFemale.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(6, 83);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(862, 23);
            this.button2.TabIndex = 11;
            this.button2.Text = "Insert Record";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // radioMale
            // 
            this.radioMale.AutoSize = true;
            this.radioMale.Checked = true;
            this.radioMale.Location = new System.Drawing.Point(430, 24);
            this.radioMale.Name = "radioMale";
            this.radioMale.Size = new System.Drawing.Size(59, 20);
            this.radioMale.TabIndex = 14;
            this.radioMale.TabStop = true;
            this.radioMale.Text = "Male";
            this.radioMale.UseVisualStyleBackColor = true;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(623, 26);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(73, 16);
            this.label13.TabIndex = 13;
            this.label13.Text = "Address :";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(18, 59);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(76, 16);
            this.label9.TabIndex = 13;
            this.label9.Text = "Surname :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(508, 28);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(83, 16);
            this.label15.TabIndex = 13;
            this.label15.Text = "Birth Date :";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(224, 57);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(59, 16);
            this.label14.TabIndex = 13;
            this.label14.Text = "E-Mail :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(224, 28);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(59, 16);
            this.label10.TabIndex = 13;
            this.label10.Text = "Phone :";
            // 
            // tbAddress
            // 
            this.tbAddress.Location = new System.Drawing.Point(702, 23);
            this.tbAddress.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbAddress.Multiline = true;
            this.tbAddress.Name = "tbAddress";
            this.tbAddress.Size = new System.Drawing.Size(166, 57);
            this.tbAddress.TabIndex = 5;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(18, 28);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 16);
            this.label5.TabIndex = 13;
            this.label5.Text = "Name :";
            // 
            // tbEmail
            // 
            this.tbEmail.Location = new System.Drawing.Point(298, 54);
            this.tbEmail.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbEmail.Name = "tbEmail";
            this.tbEmail.Size = new System.Drawing.Size(116, 22);
            this.tbEmail.TabIndex = 4;
            // 
            // tbPhone
            // 
            this.tbPhone.Location = new System.Drawing.Point(298, 25);
            this.tbPhone.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbPhone.Name = "tbPhone";
            this.tbPhone.Size = new System.Drawing.Size(116, 22);
            this.tbPhone.TabIndex = 2;
            // 
            // tbSurname
            // 
            this.tbSurname.Location = new System.Drawing.Point(92, 56);
            this.tbSurname.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbSurname.Name = "tbSurname";
            this.tbSurname.Size = new System.Drawing.Size(116, 22);
            this.tbSurname.TabIndex = 3;
            // 
            // tbName
            // 
            this.tbName.Location = new System.Drawing.Point(92, 25);
            this.tbName.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbName.Name = "tbName";
            this.tbName.Size = new System.Drawing.Size(116, 22);
            this.tbName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(14, 186);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(85, 16);
            this.label2.TabIndex = 10;
            this.label2.Text = "Identity No:";
            // 
            // tbIdentity
            // 
            this.tbIdentity.Location = new System.Drawing.Point(110, 183);
            this.tbIdentity.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.tbIdentity.Name = "tbIdentity";
            this.tbIdentity.Size = new System.Drawing.Size(116, 22);
            this.tbIdentity.TabIndex = 0;
            // 
            // btnContinue
            // 
            this.btnContinue.Location = new System.Drawing.Point(232, 184);
            this.btnContinue.Name = "btnContinue";
            this.btnContinue.Size = new System.Drawing.Size(92, 23);
            this.btnContinue.TabIndex = 11;
            this.btnContinue.Text = "Continue";
            this.btnContinue.UseVisualStyleBackColor = true;
            this.btnContinue.Click += new System.EventHandler(this.btnContinue_Click);
            // 
            // btnApproval
            // 
            this.btnApproval.Enabled = false;
            this.btnApproval.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnApproval.Location = new System.Drawing.Point(16, 330);
            this.btnApproval.Name = "btnApproval";
            this.btnApproval.Size = new System.Drawing.Size(883, 38);
            this.btnApproval.TabIndex = 11;
            this.btnApproval.Text = "Approval";
            this.btnApproval.UseVisualStyleBackColor = true;
            this.btnApproval.Click += new System.EventHandler(this.btnApproval_Click);
            // 
            // buyTicketForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(911, 383);
            this.Controls.Add(this.btnApproval);
            this.Controls.Add(this.btnContinue);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.panelPersonal);
            this.Controls.Add(this.tbIdentity);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "buyTicketForm";
            this.Text = "Buy Ticket";
            this.Load += new System.EventHandler(this.TicketBuyForm_Load);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.panelPersonal.ResumeLayout(false);
            this.panelPersonal.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblTicketCost;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label lblAirplane;
        private System.Windows.Forms.Label lblHost;
        private System.Windows.Forms.Label lblPilot;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblDepartureDate;
        private System.Windows.Forms.Label lblArrivalDate;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblArrivalCity;
        private System.Windows.Forms.Label lblDepartureCity;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox panelPersonal;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox tbIdentity;
        private System.Windows.Forms.Button btnContinue;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tbSurname;
        private System.Windows.Forms.TextBox tbName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox tbAddress;
        private System.Windows.Forms.TextBox tbPhone;
        private System.Windows.Forms.RadioButton radioFemale;
        private System.Windows.Forms.RadioButton radioMale;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox tbEmail;
        private System.Windows.Forms.DateTimePicker dtBirth;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnApproval;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label lblSeatNo;
        private System.Windows.Forms.Label label20;
    }
}