﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightReservationSystem
{
    public partial class FlightDetail : Form
    {
        Flight flight;
        public FlightDetail(Flight flight)
        {
            this.flight = flight;
            InitializeComponent();
        }

        private void FlightDetail_Load(object sender, EventArgs e)
        {
            lblTicketCost.Text = flight.ticketCost + "₺";
            lblHost.Text = flight.host;
            lblDepartureDate.Text = flight.departureDate;
            lblDepartureCity.Text = flight.departureCity;
            lblAirplane.Text = flight.airplane;
            lblPilot.Text = flight.pilot;
            lblArrivalDate.Text = flight.arrivalDate;
            lblArrivalCity.Text = flight.arrivalCity;
        }
    }
}
