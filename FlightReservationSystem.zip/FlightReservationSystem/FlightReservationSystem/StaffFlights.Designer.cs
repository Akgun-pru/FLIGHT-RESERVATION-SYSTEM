﻿namespace FlightReservationSystem
{
    partial class StaffFlightList
    {
                                private System.ComponentModel.IContainer components = null;

                                        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

                                        private void InitializeComponent()
        {
            this.flightTable = new System.Windows.Forms.DataGridView();
            this.lblBilgi = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.flightTable)).BeginInit();
            this.SuspendLayout();
            // 
            // flightTable
            // 
            this.flightTable.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.flightTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.flightTable.Location = new System.Drawing.Point(14, 43);
            this.flightTable.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.flightTable.Name = "flightTable";
            this.flightTable.Size = new System.Drawing.Size(905, 367);
            this.flightTable.TabIndex = 0;
            // 
            // lblBilgi
            // 
            this.lblBilgi.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblBilgi.Location = new System.Drawing.Point(12, 9);
            this.lblBilgi.Name = "lblBilgi";
            this.lblBilgi.Size = new System.Drawing.Size(907, 30);
            this.lblBilgi.TabIndex = 1;
            this.lblBilgi.Text = "Flights";
            this.lblBilgi.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblBilgi.Click += new System.EventHandler(this.lblBilgi_Click);
            // 
            // StaffFlightList
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(933, 424);
            this.Controls.Add(this.lblBilgi);
            this.Controls.Add(this.flightTable);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.749999F, System.Drawing.FontStyle.Bold);
            this.Margin = new System.Windows.Forms.Padding(3, 4, 3, 4);
            this.Name = "StaffFlightList";
            this.Text = "Flights of Staff";
            this.Load += new System.EventHandler(this.StaffFlightList_Load);
            ((System.ComponentModel.ISupportInitialize)(this.flightTable)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView flightTable;
        private System.Windows.Forms.Label lblBilgi;
    }
}