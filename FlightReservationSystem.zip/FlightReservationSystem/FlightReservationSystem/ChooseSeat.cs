﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightReservationSystem
{
    public partial class ChooseSeat : Form
    {
        int flightNo;
        Button lastSelection = null;
        public ChooseSeat(int flightNo)
        {
            this.flightNo = flightNo;
            InitializeComponent();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
        private void SeatSelectForm_Load(object sender, EventArgs e)
        {
            for (int i = 0; i < 40; i++)
            {
                int seatno = i + 1;
                Button btn = new Button();
                btn.BackgroundImage = btnOccupied.BackgroundImage;
                btn.BackgroundImageLayout = btnOccupied.BackgroundImageLayout;
                btn.ForeColor = btnOccupied.ForeColor;
                btn.Name = string.Concat("K_", seatno.ToString());
                btn.Text = seatno.ToString();
                btn.Size = new Size(57, 40);
                switch (i % 4)
                {
                    case 0:
                        btn.Margin = new Padding(0, 0, 5, 5);
                        break;
                    case 1:
                        btn.Margin = new Padding(0, 0, 10, 5);
                        break;
                    case 2:
                        btn.Margin = new Padding(10, 0, 0, 5);
                        break;
                    case 3:
                        btn.Margin = new Padding(5, 0, 0, 0);
                        break;
                    default:
                        btn.Margin = new Padding(0, 0, 5, 5);
                        break;
                }
                if (Database.IsSeatEmpty(flightNo, seatno))
                {
                    btn.BackColor = Color.Red;
                }
                else
                {
                    btn.BackColor = Color.Gray;
                }
                btn.Click += SeatSelectim_Click;
                flowLayoutPanel1.Controls.Add(btn);
            }
        }

        private void SeatSelectim_Click(object sender, EventArgs e)
        {
            if (lastSelection != null && lastSelection != (Button)sender)
            {
                bool isEmpty = Database.IsSeatEmpty(flightNo, int.Parse(lastSelection.Name.Split('_')[1]));
                if (isEmpty)
                {
                    lastSelection.BackColor = Color.Red;
                }
                else
                {
                    lastSelection.BackColor = Color.Gray;
                }
            }
            lastSelection = (Button)sender;
            if (lastSelection.BackColor == btnOccupied.BackColor)
            {
                btnContinue.Enabled = false;
            }
            else
            {
                lastSelection.BackColor = Color.Blue;
                btnContinue.Enabled = true;
            }
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            this.Hide();
            new buyTicketForm(flightNo, int.Parse(lastSelection.Name.Split('_')[1])).Show();
        }

        private void btnSelectim_Click(object sender, EventArgs e)
        {

        }
    }
}
