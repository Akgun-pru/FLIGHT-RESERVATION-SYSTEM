﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightReservationSystem
{
    public partial class DestinationCreate : Form
    {
        public DestinationCreate()
        {
            InitializeComponent();
        }

        private void DestinationCreate_Load(object sender, EventArgs e)
        {
            string[] cities = Database.GetColumn("SELECT CONCAT(city.no,'-',city.name) FROM city ");
            cbDeparture.Items.AddRange(cities);
            cbDeparture.SelectedIndex = 0;
            cbArrival.Items.AddRange(cities);
            cbArrival.SelectedIndex = 1;
        }

        private void btnCreate_Click(object sender, EventArgs e)
        {
            if (tbDestinationName.Text != "" && cbDeparture.SelectedIndex>=0 && cbArrival.SelectedIndex>=0)
            {
                Database.ParameteredCommand("INSERT INTO destination VALUES(@name,@departure,@arrival,@cost)", new List<SqlParameter>() { 
                new SqlParameter("@name",tbDestinationName.Text),
                new SqlParameter("@departure",cbDeparture.SelectedItem.ToString().Split('-')[0]),
                new SqlParameter("@arrival",cbArrival.SelectedItem.ToString().Split('-')[0]),
                new SqlParameter("@cost",tbCost.Text)
                });
                MessageBox.Show("Destination inserted.");
            }
            else
            {
                MessageBox.Show("At least 2 airlines should be selected.");
            }
        }
       
    }
}
