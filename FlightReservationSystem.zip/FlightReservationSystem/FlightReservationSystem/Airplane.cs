﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FlightReservationSystem
{
    public partial class AirplaneManagement : Form
    {
        string choiceNo = "-1";
        public AirplaneManagement()
        {
            InitializeComponent();
        }
        private void BrandList()
        {
            cbBrand.Items.Clear();
            string[] brands = Database.GetColumn("SELECT CONCAT(no,'-',brand) FROM airplanebrand");
            cbBrand.Items.AddRange(brands);
            cbBrand.SelectedIndex = 0;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (tbBrandName.Text != "")
            {
                Database.RunCommand("INSERT INTO airplanebrand VALUES('" + tbBrandName.Text + "')");
                BrandList();
                MessageBox.Show("Brand inserted.");
            }
        }
        private void AirplaneList()
        {
            Database.ListTable("SELECT airplane.no,airplanebrand.brand,airplane.code FROM airplane " +
                "INNER JOIN airplanebrand ON airplane.brandno = airplanebrand.no", dtAirplane, new string[] { "NO", "Brand", "Code" });
        }
        private void AirplaneManagement_Load(object sender, EventArgs e)
        {
            BrandList();
            AirplaneList();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (cbBrand.SelectedIndex >= 0 && tbKod.Text != "" && Database.GetNo("SELECT no FROM airplane WHERE code='" + tbKod.Text + "'") == "")
            {
                string brandNo = cbBrand.SelectedItem.ToString().Split('-')[0];
                Database.RunCommand("INSERT INTO airplane VALUES('" + tbKod.Text + "'," + brandNo + ")");
                AirplaneList();
            }
            else
            {
                MessageBox.Show("Invalid code or data.");
            }
        }

        private void btnCosts_Click(object sender, EventArgs e)
        {
            new AirplaneCosts(choiceNo).ShowDialog();
        }

        private void dtAirplane_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                choiceNo = dtAirplane.Rows[e.RowIndex].Cells[0].Value.ToString();
            }
            catch (Exception)
            {
                choiceNo = "-1";
            }
            if (choiceNo == "-1")
            {
                btnCosts.Enabled = false;
            }
            else btnCosts.Enabled = true;
        }
    }
}
